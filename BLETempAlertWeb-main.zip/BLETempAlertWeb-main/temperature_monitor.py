import asyncio
from asyncio import Lock
from typing import Optional, List, Dict, Any, Set, AsyncGenerator, Union, Type
from datetime import datetime
import json
import signal
import sys
import logging
from collections import deque
from dataclasses import dataclass
import argparse


from fasthtml.common import (
    Div, Button, Form, Label, Input, Select, Option, 
    H3, P, Main, Section, Article, Script, Audio, 
    Style,  # Added Style import
    Titled,
    setup_toasts,  # Add these
    add_toast,     # toast-related
)

from fasthtml.common import *

from asyncpascodevice import AsyncPASCODevice
from starlette.responses import StreamingResponse
from starlette.staticfiles import StaticFiles
from database_manager import DatabaseManager
from config_manager import DataRecordingConfig, ConfigManager, NtfyConfig  # Assuming this exists
from notification_manager import NotificationManager

from IPython.core.debugger import set_trace

# Add at the start of the file after imports
logging.basicConfig(
    level=logging.DEBUG,
    format='%(asctime)s - %(name)s - %(levelname)s - %(funcName)s - %(message)s'
)
# Set bleak backend logging to WARNING level
logging.getLogger('bleak.backends.bluezdbus.manager').setLevel(logging.WARNING)
# Set watchfiles logging to DEBUG level
logging.getLogger('watchfiles.main').setLevel(logging.WARNING) 
logger = logging.getLogger(__name__)

# Add near the top of the file after other imports
TEST_MODE: bool = False
DeviceClass = None

# Parse arguments before anything else
parser = argparse.ArgumentParser(description="Temperature Monitor")
parser.add_argument(
    "--test-mode", 
    action="store_true",
    help="Run in test mode with simulated device"
)
args, _ = parser.parse_known_args()


def initialize_device_class(test_mode: bool = False) -> None:
    """Initialize the device class based on mode"""
    global TEST_MODE, DeviceClass
    
    TEST_MODE = test_mode
    logger.info(f"Initializing in {'test' if test_mode else 'normal'} mode")
    
    if test_mode:
        try:
            from test_utils import MockPASCODevice
            DeviceClass = MockPASCODevice
            logger.info(f"Initialized mock device class: {DeviceClass.__name__}")
        except ImportError as e:
            logger.error(f"Failed to import MockPASCODevice: {e}")
            raise
    else:
        DeviceClass = AsyncPASCODevice
        logger.info(f"Initialized real device class: {DeviceClass.__name__}")


# Initialize before creating the app
initialize_device_class(args.test_mode)

if DeviceClass is None:
    logger.error("Device class not initialized properly")
    sys.exit(1)


def format_sse_event(event: str, data: str) -> str:
    """Format a server-sent event according to the SSE spec with proper chunked encoding"""
    message = [
        f"event: {event}",
        f"data: {data}",
        f"id: {datetime.now().timestamp()}",
        "retry: 15000",  # Optional retry interval
        ""  # Blank line to indicate the end of the message
    ]
    return "\n".join(message) + "\n\n"


def temp_monitor_ui(
    current_temp: Optional[float], 
    target_temp: Optional[float], 
    last_update: Optional[datetime],
    error_message: Optional[str] = None
) -> Div:
    """Generate temperature monitor UI with PicoCSS styling"""
    logger.debug(
        f"Creating UI with temps - Current: {current_temp}, Target: {target_temp}, "
        f"Last Update: {last_update}"
    )
    
    data_attrs = {
        "data-current-temp": f"{current_temp:.1f}" if current_temp is not None else "",
        "data-target-temp": f"{target_temp:.1f}" if target_temp is not None else "",
        "data-temp-alerted": "false"
    }
    
    temp_font_size = (
        state.config_manager.display_config.maximized_font_size 
        if state.maximized else "6rem"
    )
    
    return Div(
        # Error message section
        Div(
            P(error_message, role="alert"),
            cls="error"
        ) if error_message else None,
        
        Div(
            H4("Current Temperature"),
            P(
                f"{current_temp:.1f}°C" if current_temp is not None else "N/A",
                style=f"font-size: {temp_font_size}; font-weight: bold; margin: 0 0 0 0;"
            ),
            P(
                f"Last Update: {last_update.strftime('%Y-%m-%d %H:%M:%S')}" if last_update else "",
                style="font-size: 0.875rem; color: var(--muted-color); margin: 0 0 0 0;"
            ),
            role="status",
            cls="card",
            **data_attrs
        ),
        
        # Target temperature section
        Div(
            H4("Target Temperature"),
            P(f"{target_temp:.1f}°C" if target_temp is not None else "Not set"),
            cls="card"
        ),
        
        cls="container",
        **data_attrs
    )

def maximize_controls() -> Form:
    """Generate maximize checkbox control"""
    return Form(
        Label(
            Input(
                type="checkbox",
                name="maximized",
                role="switch",
                hx_post="/toggle-maximize",
                hx_target="#temperature-display"
            ),
            "Maximize Temperature Display"
        ),
        cls="card"
    )

# Create FastHTML app with default PicoCSS and custom styles
app, rt = fast_app()

# Initialize toasts
setup_toasts(app)

# Add static file handling
app.mount("/static", StaticFiles(directory="static"), name="static")

@dataclass
class AppState:
    """Thread-safe application state"""
    def __init__(self):
        self.current_temp: Optional[float] = None
        self.target_temp: Optional[float] = None
        self.last_update: Optional[datetime] = None
        self.monitoring: bool = False
        self.temp_sensor: Optional[Any] = None
        self.temperature_data: deque = deque(maxlen=3600)
        self.timestamp_data: deque = deque(maxlen=3600)
        self.found_devices: List[Any] = []
        self.error_message: Optional[str] = None
        self.lock: Lock = Lock()
        self.active_tasks: set = set()
        self._shutdown_event = asyncio.Event()
        # Add new fields to track connected device info
        self.connected_device_name: Optional[str] = None
        self.connected_device_index: Optional[int] = None
        
        # Initialize managers in correct order with logging
        logger.info("Initializing config manager")
        self.config_manager = ConfigManager()
        logger.info(f"Ntfy config: {self.config_manager.ntfy_config}")
        
        logger.info("Initializing notification manager")
        self.notification_manager = NotificationManager(self.config_manager.ntfy_config)
        
        logger.info("Initializing database manager")
        self.db_manager = DatabaseManager(self.config_manager.data_recording_config)
        self.current_run_id: Optional[int] = None
        
        # Add notifications state, initialized from config
        self.notifications_enabled: bool = self.config_manager.ntfy_config.enabled
        logger.info(f"Initial notification state: {self.notifications_enabled}")
        self.maximized: bool = False

    def add_task(self, task: asyncio.Task) -> None:
        """Track a new async task"""
        self.active_tasks.add(task)
        task.add_done_callback(self.active_tasks.discard)

    async def disconnect_current_device(self) -> None:
        """Safely disconnect current device if connected.
        
        This method ensures thread-safe disconnection of the current temperature sensor
        by storing the reference before attempting to disconnect.
        """
        
        async with self.lock:
            current_sensor = self.temp_sensor
            if current_sensor is not None:
                try:
                    await current_sensor.disconnect()
                    logger.info("Disconnected from current device")
                except Exception as e:
                    logger.error(f"Error disconnecting device: {e}", exc_info=True)
            # Clear connected device information
            await self.clear_connected_device()

    async def reconnect_device(self) -> bool:
        """Attempt to reconnect to the last known device"""
        if (self.connected_device_name and 
            self.connected_device_index is not None and 
            self.found_devices):
            try:
                device = self.found_devices[self.connected_device_index]
                if device.name == self.connected_device_name:
                    connected_device = await safe_connect(device)
                    if connected_device:
                        self.temp_sensor = connected_device
                        return True
            except Exception as e:
                logger.error(f"Error reconnecting to device: {e}")
        return False

    async def set_connected_device(self, device: Any, index: int) -> None:
        """Store connected device information"""
        self.temp_sensor = device
        self.connected_device_name = device.name
        self.connected_device_index = index

    async def clear_connected_device(self) -> None:
        """Clear connected device information"""
        self.temp_sensor = None
        self.connected_device_name = None
        self.connected_device_index = None


# Create app state  
state = AppState()

async def create_ble_device() -> Any:
    """Creates and initializes a PASCO device instance (real or mock)"""
    if DeviceClass is None:
        raise RuntimeError("Device class not initialized. Did you call initialize_device_class()?")
        
    logger.info(f"Creating {'mock' if TEST_MODE else 'real'} BLE device using {DeviceClass.__name__}")
    return DeviceClass()

async def safe_scan(device: Any) -> list:
    """Performs a device scan (real or mock)"""
    try:
        logger.info(f"Starting {'mock' if TEST_MODE else 'real'} device scan")
        if DeviceClass is None:
            raise RuntimeError("Device class not initialized. Did you call set_test_mode()?")
        
        devices = await DeviceClass.scan()
        logger.info(f"Scan found {len(devices)} devices")
        return devices
    except Exception as e:
        logger.error(f"Error during scan: {str(e)}", exc_info=True)
        raise


# Add this near the top with other constants
BUTTON_STYLE = "width: 250px; height: 40px; line-height: 1; padding: 0;"

def target_temp_form() -> Form:
    """Generate target temperature form with PicoCSS styling"""
    return Form(
        Div(  # Flex container for input and button
            Input(
                type="number",
                step="0.1",
                name="target_temp",
                placeholder="Enter target temperature",
                style=BUTTON_STYLE  # Match button width/height
            ),
            Button(
                "Set",
                type="submit",
                cls="primary",
                style=BUTTON_STYLE
            ),
            style="display: flex; align-items: center; gap: 0.5rem; max-width: 520px;"
        ),
        hx_post="/set-target",
        hx_target="#temperature-display"
    )

def monitoring_controls() -> Div:
    """Generate monitoring control buttons with PicoCSS styling"""
    return Div(
        Button(
            "Start Monitoring" if not state.monitoring else "Stop Monitoring",
            id="toggle-monitoring",
            cls="primary" if not state.monitoring else "secondary",
            style=BUTTON_STYLE,
            hx_post="/toggle-monitoring",
            hx_target="#monitoring-button-container",
            hx_swap="outerHTML"
        ),
        id="monitoring-button-container",
        style="display: flex; justify-content: space-between; align-items: center;"
    )


def target_temp_form_old() -> Form:
    """Generate target temperature form with PicoCSS styling"""
    return Form(
        Div(  # Group input and button in a div
            Input(
                type="number",
                step="0.1",
                name="target_temp",
                placeholder="Enter target temperature"
            ),
            Button(
                "Set",
                type="submit",
                cls="primary",  # Changed to outline for visual distinction
                style="width: 150px;"  # Fixed width for consistency
            ),
            cls="grid",  # PicoCSS grid for form elements
            style="--grid-spacing: 0.5rem; --grid-columns: auto 150px;"  # Fixed width column for button
        ),
        hx_post="/set-target",
        hx_target="#temperature-display"
    )

def monitoring_controls_old() -> Div:
    """Generate monitoring control buttons with PicoCSS styling"""
    return Div(
        Button(
            "Start Monitoring",
            id="toggle-monitoring",
            cls="primary",
            style="width: 150px;",  # Same fixed width as Set button
            hx_post="/toggle-monitoring",
            hx_target="#monitoring-container",
            hx_swap="outerHTML"
        ) if not state.monitoring else Button(
            "Stop Monitoring",
            id="toggle-monitoring",
            cls="secondary",
            style="width: 150px;",  # Same fixed width as Set button
            hx_post="/toggle-monitoring",
            hx_target="#monitoring-container",
            hx_swap="outerHTML"
        ),
        id="monitoring-container",
        style="display: flex; justify-content: flex-start;"
    )

# Add this new function for notification controls UI
def notification_controls(notifications_enabled: bool) -> Div:
    """Generate notification controls UI with PicoCSS styling
    
    Args:
        notifications_enabled: Current state of notifications
        
    Returns:
        Div: Container with notification controls
    """
    return Div(
        H3("Notifications"),
        Form(
            Label(
                Input(
                    type="checkbox",
                    name="notifications_enabled",
                    checked=notifications_enabled,
                    role="switch"  # PicoCSS switch role
                ),
                "Enable Notifications"
            ),
            hx_post="/toggle-notifications",
            hx_trigger="change",
            hx_swap="none"
        ),
        cls="card",  # PicoCSS card component
        id="notification-controls"
    )

@rt("/")
async def get(session):
    """Main page route"""
    device_list_content = device_connection_ui(
        state.found_devices,
        state.temp_sensor,
        state.connected_device_index
    )

    return Titled(
        "Temperature Monitor",
        Style("""
            .fh-toast-container {
                position: fixed !important;
                top: auto !important;
                bottom: 1rem !important;
                left: 1rem !important;
                right: auto !important;
                transform: none !important;
                z-index: 1000;
                display: flex;
                flex-direction: column;
                align-items: flex-start;
                width: auto;
                pointer-events: none;
            }
            .fh-toast {
                background: var(--card-background-color);
                color: var(--card-text-color);
                padding: 1rem;
                border-radius: var(--border-radius);
                margin-bottom: 0.5rem;
                max-width: 300px;
                width: auto;
                text-align: left;
                box-shadow: var(--card-box-shadow);
                pointer-events: auto;
                border: 1px solid;
            }
            .fh-toast-info { 
                border-color: var(--primary); 
            }
            .fh-toast-success { 
                border-color: var(--form-element-valid-border-color); 
            }
            .fh-toast-warning { 
                border-color: var(--form-element-invalid-border-color); 
            }
            .fh-toast-error { 
                border-color: var(--form-element-invalid-border-color);
            }
        """),
        Script(src="https://unpkg.com/htmx.org@1.9.6"),
        Script(src="https://unpkg.com/htmx-ext-sse@2.2.1/sse.js"),
        # Add audio elements with different alert types
        Audio(
            id="temp-alert",
            src="/static/alarm.mp3",
            style="display: none",
            preload="auto"
        ),
        Audio(
            id="temp-warning",
            src="/static/rooster.mp3", 
            style="display: none",
            preload="auto"
        ),
        # Add alert dialog
        Dialog(  # Using PicoCSS dialog instead of custom modal
            Article(  # PicoCSS article for content grouping
                H3("Temperature Alert!"),
                P(id="alert-message"),
                Div(
                    Button(
                        "Dismiss",
                        id="dismiss-alert",
                        cls="primary",
                        style=BUTTON_STYLE
                    ),
                    Button(
                        "Mute Alerts",
                        id="mute-alerts",
                        cls="secondary",
                        style=BUTTON_STYLE
                    ),
                    cls="grid",  # PicoCSS grid
                    style="gap: 0.5rem;"  # Add gap between alert buttons
                )
            ),
            id="alert-dialog",
            role="alertdialog"
        ),
        Main(
            Section(
                device_list_content,
                Div(
                    # Temperature display with SSE updates
                    Div(
                        Div( 
                            Article(  # Wrap the UI in Article to match SSE updates
                                temp_monitor_ui(
                                    state.current_temp,
                                    state.target_temp,
                                    state.last_update,
                                    state.error_message
                                )
                            ),
                            id="temperature-display",
                            cls="margin-bottom",
                            sse_swap="message"
                        ),
                        hx_ext="sse",
                        sse_connect="/temperature-stream",
                    ),
                    # Add maximize control before notifications
                    maximize_controls(),
                    notification_controls(state.notifications_enabled),
                    target_temp_form(),
                    monitoring_controls(),
                    cls="controls-container",
                ),
                cls="container"
            )
        ),
        # Add back the alert handling JavaScript
        Script("""
            document.addEventListener('DOMContentLoaded', function() {
                let alertsMuted = false;
                const alertDialog = document.getElementById('alert-dialog');
                
                function checkTemperature(display) {
                    if (!display) {
                        console.log('No display element provided');
                        return;
                    }
                    
                    const tempDiv = display.querySelector('.card[role="status"]');  // Updated selector for PicoCSS
                    if (!tempDiv) {
                        console.log('Temperature div not found');
                        return;
                    }
                    
                    const currentTemp = parseFloat(tempDiv.getAttribute('data-current-temp'));
                    const targetTemp = parseFloat(tempDiv.getAttribute('data-target-temp'));
                    const hasAlerted = tempDiv.getAttribute('data-temp-alerted') === 'true';
                    
                    console.log('Checking temperature:', { currentTemp, targetTemp, hasAlerted });
                    
                    if (isNaN(currentTemp) || isNaN(targetTemp) || alertsMuted) {
                        return;
                    }
                    
                    const tempDiff = Math.abs(currentTemp - targetTemp);
                    
                    if (!hasAlerted) {
                        if (tempDiff <= 0.5) {
                            playAlert('temp-alert', `Target temperature reached! Current: ${currentTemp.toFixed(1)}°C`);
                            tempDiv.setAttribute('data-temp-alerted', 'true');
                        } else if (tempDiff <= 2.0) {
                            playAlert('temp-warning', `Approaching target temperature! Current: ${currentTemp.toFixed(1)}°C`);
                            tempDiv.setAttribute('data-temp-alerted', 'true');
                        }
                    } else if (tempDiff > 2.0) {
                        tempDiv.setAttribute('data-temp-alerted', 'false');
                    }
                }

                function playAlert(audioId, message) {
                    if (alertsMuted) return;
                    
                    const audio = document.getElementById(audioId);
                    const alertMessage = document.getElementById('alert-message');
                    
                    if (audio && alertDialog && alertMessage) {
                        audio.play().catch(error => console.warn('Audio playback failed:', error));
                        alertMessage.textContent = message;
                        alertDialog.showModal();
                    }
                }

                function stopAllAlerts() {
                    document.querySelectorAll('audio').forEach(audio => {
                        audio.pause();
                        audio.currentTime = 0;
                    });
                    alertDialog.close();
                }
                
                // Handle SSE messages
                document.body.addEventListener('htmx:sseMessage', function(event) {
                    console.log('Received SSE message:', event.detail);
                    const parser = new DOMParser();
                    const doc = parser.parseFromString(event.detail.data, 'text/html');
                    checkTemperature(doc);
                });
                
                // Check after HTMX swaps
                document.body.addEventListener('htmx:afterSwap', function(evt) {
                    console.log('HTMX swap occurred');
                    checkTemperature(document);
                });
                
                // Handle alert controls
                const dismissButton = document.getElementById('dismiss-alert');
                const muteButton = document.getElementById('mute-alerts');
                
                if (dismissButton) {
                    dismissButton.addEventListener('click', stopAllAlerts);
                }
                
                if (muteButton) {
                    muteButton.addEventListener('click', function() {
                        alertsMuted = !alertsMuted;
                        this.textContent = alertsMuted ? 'Unmute Alerts' : 'Mute Alerts';
                        stopAllAlerts();
                    });
                }
                
                // Add keyboard shortcut to dismiss alert
                document.addEventListener('keydown', function(e) {
                    if (e.key === 'Escape') {
                        stopAllAlerts();
                    }
                });
            });
        """)
    )


# Add this helper function near the top with other UI functions
def device_connection_ui(devices: List[Any], connected_device: Optional[Any] = None, selected_index: Optional[int] = None) -> Div:
    """Generate the device connection UI with consistent styling"""
    # Common flexbox styling - add align-items: stretch to ensure consistent heights
    flex_style = "display: flex; align-items: stretch; gap: 0.5rem;"
    
    # Create the scan button - add height and padding to match form elements
    scan_button = Button(
        "Scan for Devices",
        cls="primary",
        style=BUTTON_STYLE,
        hx_post="/scan",
        hx_target="#device-connection-container"
    )
    
    # Common select element for both connected and disconnected states
    device_select = Select(
        *[Option(
            device.name,
            value=str(i),
            selected=(i == selected_index)
        ) for i, device in enumerate(devices)] if devices else [
            Option("No devices found - scan first", disabled=True)
        ],
        name="device_index",
        id="device-select",
        style=BUTTON_STYLE
    )

    # Create form based on connection state
    connection_form = Form(
        device_select,
        Button(
            "Disconnect" if connected_device else "Connect",
            type="submit",
            cls="secondary" if connected_device else "primary",
            style=BUTTON_STYLE
        ),
        id="connect-form",
        name="connect-form",
        enctype="multipart/form-data",
        hx_post="/disconnect" if connected_device else "/connect",
        hx_target="#device-connection-container",
        style=flex_style
    )

    # Create the main controls container with scan button and form
    controls_container = Div(
        scan_button,
        connection_form,
        style=flex_style
    )

    # Return just the controls container without the connection status
    return Div(
        controls_container,
        id="device-connection-container",
        cls="margin-bottom"
    )

# Update the /scan endpoint to include toast
@rt("/scan")
async def post(session=None):
    """Handle device scanning"""
    logger.info("Starting device scan")
    try:
        state.temp_sensor = await create_ble_device()
        found_devices = await safe_scan(state.temp_sensor)
        
        # Even if no devices found, we'll still show the UI structure
        state.found_devices = found_devices
        logger.info(f"Found {len(found_devices)} devices: {[device.name for device in found_devices]}")
        
        # Add toast for scan results
        if found_devices:
            add_toast(session, f"Found {len(found_devices)} devices", "success")
        else:
            add_toast(session, "No devices found", "warning")
            
        return device_connection_ui(found_devices)
        
    except Exception as e:
        error_msg = f"Error during device scan: {str(e)}"
        logger.error(error_msg, exc_info=True)
        add_toast(session, error_msg, "error")
        return device_connection_ui([])

async def safe_connect(device_to_connect: Any) -> Optional[Any]:
    """
    Safely connects to a BLE device in an async context.
    
    Args:
        device_to_connect: The BLEDevice to connect to
    
    Returns:
        Optional[Any]: Connected device instance or None if connection fails
    """
    try:
        logger.info(f"Starting connection attempt to device: {device_to_connect.name}")
        
        if DeviceClass is None:
            logger.error("DeviceClass is not initialized")
            return None
            
        logger.info(f"Using device class: {DeviceClass.__name__}")
        connected_device = await DeviceClass.connect(device_to_connect)
        
        if connected_device:
            logger.info(f"Successfully connected to device {device_to_connect.name}")
            return connected_device
        else:
            logger.warning(f"Connection failed to device {device_to_connect.name} - returned None")
            return None
            
    except Exception as e:
        logger.error(f"Error during connect: {str(e)}", exc_info=True)
        return None


# Update the /connect endpoint to use the new helper
@rt("/connect")
async def post(device_index: Optional[str] = None, session=None):
    """Handle device connection with proper cleanup"""
    logger.info(f"Connect endpoint called with device_index: {device_index}")
    
    try:
        if device_index is None:
            msg = "No device selected"
            logger.warning(msg)
            add_toast(session, msg, "warning")
            return device_connection_ui(state.found_devices)
            
        device_idx = int(device_index)
        if device_idx >= len(state.found_devices):
            msg = f"Invalid device index: {device_idx}"
            logger.error(msg)
            add_toast(session, msg, "error")
            return device_connection_ui(state.found_devices)
            
        device = state.found_devices[device_idx]
        logger.info(f"Attempting to connect to device: {device.name}")
        temp_sensor = await create_ble_device()
        logger.debug(f"Created new device instance: {temp_sensor}")
        
        connected_device = await safe_connect(device)
        logger.debug(f"Connection attempt result: {connected_device}")
        
        if connected_device:
            logger.info(f"Successfully connected to device: {device.name}")
            await state.set_connected_device(connected_device, device_idx)
            add_toast(session, f"Connected to {device.name}", "success")
            return device_connection_ui(
                state.found_devices,
                connected_device,
                device_idx
            )
        else:
            msg = f"Failed to connect to device: {device.name}"
            logger.error(msg)
            add_toast(session, msg, "error")
            return device_connection_ui(state.found_devices)
            
    except Exception as e:
        error_msg = f"Error connecting: {str(e)}"
        logger.error(error_msg, exc_info=True)
        add_toast(session, error_msg, "error")
        return device_connection_ui(state.found_devices)

# Fix the disconnect endpoint
@rt("/disconnect")
async def post(session=None):
    """Handle device disconnection"""
    logger.info("Disconnecting device")
    try:
        await state.disconnect_current_device()
        logger.info("Device disconnected successfully")
        add_toast(session, "Device disconnected", "info")
        return device_connection_ui(state.found_devices)
    except Exception as e:
        error_msg = f"Error disconnecting device: {str(e)}"
        logger.error(error_msg, exc_info=True)
        add_toast(session, error_msg, "error")
        return device_connection_ui(state.found_devices)


@rt("/set-target")
async def post(target_temp: float):
    """Handle setting target temperature"""
    logger.info(f"Setting target temperature to {target_temp}°C")
    state.target_temp = target_temp
    return Article(
        temp_monitor_ui(state.current_temp, state.target_temp, state.last_update)
    )


@rt("/toggle-monitoring")
async def post(session=None):
    """Handle toggling monitoring state"""
    async with state.lock:
        if not state.monitoring:
            if state.connected_device_name is None:  # Check for actual connection
                add_toast(session, "Cannot start monitoring: No device connected", "error")
                return monitoring_controls()
                
            state.monitoring = True
            monitoring_task = asyncio.create_task(monitor_temperature())
            state.add_task(monitoring_task)
            add_toast(session, "Monitoring started", "success")
        else:
            state.monitoring = False
            add_toast(session, "Monitoring stopped", "info")
            
        return monitoring_controls()



async def monitor_temperature():
    """Background task for temperature monitoring"""
    logger.info("Starting temperature monitoring")
    error_count = 0
    MAX_ERRORS = 3
    last_notification_temp = None
    
    try:
        # Initialize database
        await state.db_manager.initialize()
        
        # Safely determine the direction
        if state.target_temp is not None and state.current_temp is not None:
            direction = "heating" if state.target_temp > state.current_temp else "cooling"
        else:
            direction = "unknown"
            logger.warning("Cannot determine direction: target_temp or current_temp is None")
        
        state.current_run_id = await state.db_manager.create_run(
            target_temp=state.target_temp or 0.0,
            direction=direction
        )
        logger.info(f"Started new monitoring run with ID: {state.current_run_id}")
        
        while state.monitoring and state.temp_sensor and not state._shutdown_event.is_set():
            try:
                temperature = await state.temp_sensor.async_read_data('Temperature')
                timestamp = datetime.now()
                
                logger.debug(f"Read temperature: {temperature}°C at {timestamp}")
                
                async with state.lock:
                    state.current_temp = temperature
                    state.last_update = timestamp
                    state.temperature_data.append(temperature)
                    state.timestamp_data.append(timestamp.timestamp())
                    state.error_message = None
                    error_count = 0
                    
                    # Log temperature to database
                    await state.db_manager.record_temperature(
                        state.current_run_id,
                        temperature
                    )
                    
                    # Handle notifications if enabled - use state instead of config
                    if state.notifications_enabled and state.target_temp is not None:
                        temp_diff = abs(temperature - state.target_temp)
                        logger.info(f"Checking notifications - enabled: {state.notifications_enabled}, "
                                    f"temp_diff: {temp_diff}, target: {state.target_temp}, "
                                    f"last_notification_temp: {last_notification_temp}")
                        
                        # Target temperature reached (within 0.5°C)
                        if temp_diff <= 0.5 and (last_notification_temp is None or abs(temperature - last_notification_temp) > 0.5):
                            logger.info("Sending target reached notification")
                            success = await state.notification_manager.send_notification(
                                message=f"Target temperature reached: {temperature:.1f}°C",
                                title="Temperature Alert",
                                tags=["thermometer", "target-reached"],
                                priority="default"
                            )
                            logger.info(f"Notification sent successfully: {success}")
                            if success:
                                last_notification_temp = temperature
                            
                        # Approaching target (within 2.0°C)
                        elif temp_diff <= 2.0 and temp_diff > 0.5 and (last_notification_temp is None or abs(temperature - last_notification_temp) > 1.0):
                            await state.notification_manager.send_notification(
                                message=f"Approaching target temperature! Current: {temperature:.1f}°C",
                                title="Temperature Warning",
                                tags=["thermometer", "approaching"],
                                priority="low"
                            )
                            last_notification_temp = temperature
                            
                        # Temperature exceeded target by more than 2.0°C
                        elif temperature > state.target_temp + 2.0 and (last_notification_temp is None or temperature - last_notification_temp > 2.0):
                            await state.notification_manager.send_notification(
                                message=f"Temperature exceeded target by {(temperature - state.target_temp):.1f}°C! Current: {temperature:.1f}°C",
                                title="Temperature Alert",
                                tags=["thermometer", "exceeded"],
                                priority="high"
                            )
                            last_notification_temp = temperature
                
                logger.debug(f"Updated state and logged temperature: {state.current_temp}°C")
                await asyncio.sleep(1)
                
            except Exception as e:
                error_count += 1
                error_msg = f"Error reading temperature: {str(e)}"
                logger.error(error_msg, exc_info=True)
                
                async with state.lock:
                    state.error_message = error_msg
                
                if error_count >= MAX_ERRORS:
                    logger.error("Max errors reached, stopping monitoring")
                    if state.config_manager.ntfy_config.enabled:
                        await state.notification_manager.send_notification(
                            message="Temperature monitoring stopped due to errors",
                            title="Monitoring Error",
                            tags=["thermometer", "error"],
                            priority="high"
                        )
                    state.monitoring = False
                    break
                
                await asyncio.sleep(1)
    except Exception as e:
        logger.error(f"Error in monitoring task: {str(e)}", exc_info=True)
        if state.config_manager.ntfy_config.enabled:
            await state.notification_manager.send_notification(
                message=f"Monitoring error: {str(e)}",
                title="System Error",
                tags=["thermometer", "error"],
                priority="high"
            )
        raise
    finally:
        logger.info("Temperature monitoring stopped")



async def update_display():
    """Update the temperature display"""
    logger.debug(
        f"Updating display - Current: {state.current_temp}°C, "
        f"Target: {state.target_temp}°C, "
        f"Last Update: {state.last_update}"
    )
    display_html = temp_monitor_ui(
        state.current_temp, 
        state.target_temp, 
        state.last_update,
        state.error_message
    )
    return display_html

async def update_chart():
    """Update the temperature chart"""
    logger.debug(f"Updating chart with {len(state.temperature_data)} data points")
    chart_data = {
        "data": [
            {
                "x": [datetime.fromtimestamp(t).strftime('%Y-%m-%d %H:%M:%S') 
                     for t in state.timestamp_data],
                "y": state.temperature_data,
                "type": "scatter",
                "name": "Temperature"
            },
            {
                "x": [datetime.fromtimestamp(t).strftime('%Y-%m-%d %H:%M:%S') 
                     for t in state.timestamp_data],
                "y": [state.target_temp] * len(state.timestamp_data),
                "type": "scatter",
                "name": "Target",
                "line": {"dash": "dash"}
            }
        ],
        "layout": {
            "title": "Temperature vs Time",
            "xaxis": {"title": "Time"},
            "yaxis": {"title": "Temperature (°C)"}
        }
    }
    return Script(f"Plotly.newPlot('temperature-chart', {json.dumps(chart_data)});")

@rt("/temperature-update")
async def get():
    """Handle temperature display updates"""
    return temp_monitor_ui(state.current_temp, state.target_temp, state.last_update)


@rt("/temperature-stream")
async def get():
    """Server-sent events endpoint for real temperature updates"""
    logger.info("Real temperature SSE endpoint called")
    
    async def real_event_generator():
        last_temp = None
        logger.info("Real event generator starting")
        
        while state.monitoring and not state._shutdown_event.is_set():
            try:
                async with state.lock:
                    current_temp = state.current_temp
                    target_temp = state.target_temp
                    last_update = state.last_update
                    error_msg = state.error_message
                
                logger.info(f"Current temp: {current_temp}°C {last_update} {error_msg}")
                
                # Generate the updated display HTML
                display = temp_monitor_ui(
                    current_temp=current_temp,
                    target_temp=target_temp,
                    last_update=last_update,
                    error_message=error_msg
                )
                
                # Convert the display to HTML FT component
                html_content = Article(display)
                
                yield sse_message(html_content)
                await asyncio.sleep(2)
                
            except asyncio.CancelledError:
                logger.info("Real generator cancelled")
                break
            except Exception as e:
                logger.error(f"Error in real generator: {str(e)}", exc_info=True)
                yield sse_message(f"Error: {str(e)}")
                continue

    return EventStream(real_event_generator())

@rt("/test-temperature-stream")
async def get():
    """Test SSE endpoint that generates dummy temperature values"""
    logger.info("Test SSE endpoint called")
    
    async def test_event_generator():
        import math
        temp = 20.0
        counter = 0
        
        while True:
            try:
                # Generate a sine wave temperature pattern
                current_temp = temp + 2 * math.sin(counter / 10)
                current_time = datetime.now()
                
                async with state.lock:
                    # Update state
                    state.current_temp = current_temp
                    state.last_update = current_time
                    
                    # Generate the updated display HTML
                    display = temp_monitor_ui(
                        current_temp=current_temp,
                        target_temp=state.target_temp,
                        last_update=current_time,
                        error_message=None
                    )
                    
                    # Convert the display to HTML FT component
                    html_content = Article(display)

                    # Log the HTML content for debugging
                    logger.debug(f"Generated HTML content: {html_content}")
                    
                    # Send the HTML content as SSE message
                    yield sse_message(html_content)
                
                counter += 1
                await asyncio.sleep(1)
                
            except asyncio.CancelledError:
                logger.info("Test generator cancelled")
                break
            except Exception as e:
                logger.error(f"Error in test generator: {str(e)}", exc_info=True)
                yield sse_message(f"Error: {str(e)}")
                continue

    return EventStream(test_event_generator())



async def cleanup():
    """Cleanup function to disconnect device and stop monitoring"""
    logger.info("Starting cleanup...")
    
    # Signal shutdown to all tasks
    state._shutdown_event.set()
    
    # Stop monitoring
    state.monitoring = False
    
    # Cancel all active tasks
    tasks = list(state.active_tasks)
    if tasks:
        for task in tasks:
            if not task.done():
                task.cancel()
        
        await asyncio.gather(*tasks, return_exceptions=True)
    
    # Close database connection
    if state.db_manager:
        await state.db_manager.close()
    
    # Disconnect device
    await state.disconnect_current_device()
    
    logger.info("Cleanup completed")

def signal_handler(sig, frame):
    """Handle shutdown signals"""
    logger.info(f"Received signal {sig}")
    
    try:
        loop = asyncio.get_running_loop()
    except RuntimeError:
        loop = asyncio.new_event_loop()
        asyncio.set_event_loop(loop)
        
    async def shutdown():
        await cleanup()
        loop.stop()
    
    try:
        if loop.is_running():
            loop.create_task(shutdown())
        else:
            loop.run_until_complete(cleanup())
    except Exception as e:
        logger.error(f"Error during cleanup: {str(e)}", exc_info=True)
    finally:
        logger.info("Shutting down...")
        sys.exit(0)

# Register signal handlers
signal.signal(signal.SIGINT, signal_handler)
signal.signal(signal.SIGTERM, signal_handler)

# Add new route to handle notification toggle
@rt("/toggle-notifications")
async def post(notifications_enabled: Optional[str] = None):
    """Handle toggling notifications"""
    # Convert string form value to boolean
    enabled = notifications_enabled == "on"
    logger.info(f"Toggling notifications: {enabled} (raw value: {notifications_enabled})")
    
    try:
        # Update both state and config
        state.notifications_enabled = enabled
        state.config_manager.update_ntfy_config(enabled=enabled)
        logger.info(f"Updated notification state: {state.notifications_enabled}")
        return ""  # Empty response as we're using hx-swap="none"
    except Exception as e:
        logger.error(f"Error toggling notifications: {e}", exc_info=True)
        return "Error updating notification settings"

def status_dialog() -> Dialog:
    """Generate status dialog for critical notifications"""
    return Dialog(
        Article(
            H3("Status Update"),
            P(id="status-message"),
            Button(
                "Dismiss",
                cls="primary",
                onclick="this.closest('dialog').close()"
            ),
        ),
        id="status-dialog",
        style="position: fixed; bottom: 1rem; right: 1rem;"
    )

# Update status via SSE
@rt("/status-stream")
async def get():
    async def status_generator():
        while True:
            status = {
                "message": state.error_message,
                "type": "error" if state.error_message else "info",
                "connection": state.temp_sensor is not None
            }
            yield sse_message(status_dialog())
            await asyncio.sleep(1)
    return EventStream(status_generator())

# Add route to handle maximize toggle
@rt("/toggle-maximize")
async def post(maximized: Optional[str] = None):
    """Handle toggling maximized state"""
    state.maximized = maximized == "on"
    return Article(  # Wrap the UI in Article to match SSE updates
        temp_monitor_ui(
            state.current_temp,
            state.target_temp,
            state.last_update,
            state.error_message
        )
    )

if __name__ == "__main__":
    parser = argparse.ArgumentParser(description="Temperature Monitor")
    parser.add_argument(
        "--test-mode", 
        action="store_true",
        help="Run in test mode with simulated device"
    )
    args = parser.parse_args()
    
    try:
        # Initialize device class before starting server
        initialize_device_class(args.test_mode)
        
        if DeviceClass is None:
            raise RuntimeError("Device class not initialized properly")
            
        logger.info(f"Starting server in {'test' if TEST_MODE else 'normal'} mode")
        serve()
    except Exception as e:
        logger.error(f"Failed to start server: {e}")
        sys.exit(1)