# Temperature Alarm

A Python application that monitors temperature from PASCO BLE sensors and triggers alerts when target temperatures are reached. Features a web-based interface with real-time temperature display and multiple notification channels.

## Installation

1. **Python Requirements:**
   - Python 3.11 or later
   - Required packages:
     ```bash
     pip install -r requirements.txt
     ```

2. **Directory Setup:**
   Create these directories for application data and logs:
   ```bash
   mkdir -p data logs
   ```

3. **Configuration:**
   Create `config/config.toml` with your settings:
   ```toml
   [ntfy]
   enabled = true
   server = "https://ntfy.sh"
   topic = "your-topic-name"
   username = ""
   password = ""
   priority = "high"
   tags = ["thermometer"]

   [voice]
   enabled = true

   [data_recording]
   enabled = true
   path = "data/temperature_logs.db"

   [logging]
   level = "INFO"
   file = "logs/temperature_alarm.log"
   ```

## Running the Application

1. **Connect PASCO Sensor:** Ensure your PASCO BLE sensor is powered on and within range.

2. **Start the Application:**
   ```bash
   python temperature_monitor.py
   ```

   For testing without a physical sensor:
   ```bash
   python temperature_monitor.py --test-mode
   ```

## Features

- **Automated Device Connection:** Automatically discovers and connects to PASCO BLE sensors
- **Real-time Web Interface:**
  - Live temperature display
  - Historical temperature graph
  - Target temperature controls
  - Maximizable temperature display
- **Multi-channel Notifications:**
  - Push notifications via ntfy
  - Database logging of temperature data
  - Visual and audio alerts in web interface
- **Configurable Settings:**
  - Notification preferences
  - Data logging options
  - Display customization

## Web Interface Usage

1. **Device Connection:** The application automatically scans for and connects to available PASCO sensors.

2. **Set Target Temperature:** Enter your desired target temperature in the input field.

3. **Monitor Temperature:**
   - View current temperature in real-time
   - Track temperature history in the graph
   - Receive alerts when:
     - Target temperature is reached (±0.5°C)
     - Approaching target (within 2.0°C)
     - Temperature exceeds target by more than 2.0°C

4. **Customize Display:**
   - Toggle temperature display size
   - Enable/disable notifications
   - View system status and error messages

## Mobile Notifications

1. **Install ntfy app:**
   - [Android](https://play.google.com/store/apps/details?id=io.heckel.ntfy)
   - [iOS](https://apps.apple.com/us/app/ntfy/id1625396347)

2. **Subscribe to Updates:**
   - Add subscription in ntfy app
   - Enter: `https://ntfy.sh/your-topic-name`
   - Add authentication if configured

## Configuration Options

### Notifications [ntfy]
- `enabled`: Enable/disable push notifications
- `server`: ntfy server URL (default: "https://ntfy.sh")
- `topic`: Your notification topic
- `username/password`: Optional authentication
- `priority`: Notification importance ("default", "low", "high", "urgent")
- `tags`: Emoji tags for notifications

### Data Recording [data_recording]
- `enabled`: Enable/disable temperature logging
- `path`: SQLite database location

### Logging [logging]
- `level`: Log level ("DEBUG", "INFO", "WARNING", "ERROR")
- `file`: Log file location

## Development

- **Test Mode:** Use `--test-mode` flag for development without a physical sensor
- **Logging:** Check `logs/temperature_alarm.log` for detailed operation logs
- **Database:** Temperature data stored in SQLite at configured location

## Contributing

Contributions welcome! Please feel free to submit issues or pull requests.

## License

MIT License

## Acknowledgments

- [ntfy](https://ntfy.sh) - Push notification service
- [PASCO](https://www.pasco.com) - BLE sensor hardware
- [FastHTML](https://github.com/byteface/fasthtml) - Web interface framework
