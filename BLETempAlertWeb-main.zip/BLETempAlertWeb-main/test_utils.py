from typing import Optional, List, Any
from dataclasses import dataclass
import math
import asyncio
import logging
import random
from datetime import datetime

logging.basicConfig(level=logging.DEBUG)
logger = logging.getLogger(__name__)

@dataclass
class MockBLEDevice:
    """Mock BLE device for testing"""
    name: str
    address: str

class MockPASCODevice:
    """Mock PASCO device for testing purposes"""
    
    def __init__(self, name: str = "Test PASCO Sensor", address: str = "00:11:22:33:44:55"):
        """Initialize mock device with optional name and address"""
        self.name = name
        self.address = address
        self.connected = False
        self._base_temp = 20.0
        self._counter = 0
        self._current_temp = self._base_temp
        self._target_temp = 100.0  # Maximum possible temperature
        self._heating_rate = 0.2  # Degrees per second when heating
        self._cooling_rate = 0.1  # Degrees per second when cooling
        self._last_update = datetime.now()
        
    @classmethod
    async def scan(cls) -> List[MockBLEDevice]:
        """Simulate device scanning - changed to classmethod"""
        logger.info("Mock device scanning...")
        await asyncio.sleep(1)  # Simulate scan delay
        devices = [
            MockBLEDevice("Test PASCO Sensor", "00:11:22:33:44:55"),
            MockBLEDevice("Another Test Sensor", "66:77:88:99:AA:BB")
        ]
        logger.info(f"Mock scan found devices: {[d.name for d in devices]}")
        return devices    
        
    @classmethod
    async def connect(cls, device: MockBLEDevice) -> 'MockPASCODevice':
        """Simulate device connection"""
        logger.info(f"Mock connecting to device: {device.name}")
        await asyncio.sleep(0.5)  # Simulate connection delay
        mock_device = cls(device.name, device.address)
        mock_device.connected = True
        logger.info(f"Mock connected to device: {device.name}")
        return mock_device
    
    async def disconnect(self) -> None:
        """Simulate device disconnection"""
        logger.info(f"Mock disconnecting from device: {self.name}")
        await asyncio.sleep(0.2)  # Simulate disconnection delay
        self.connected = False
        logger.info("Mock device disconnected")
        
    async def async_read_data_old(self, data_type: str) -> float:
        """Simulate temperature reading with a sine wave pattern"""
        if data_type != 'Temperature':
            raise ValueError(f"Unsupported data type: {data_type}")
            
        # Generate a sine wave temperature pattern
        self._counter += 1
        temperature = self._base_temp + 2 * math.sin(self._counter / 10)
        
        # Add some random noise
        from random import uniform
        temperature += uniform(-0.2, 0.2)
        
        await asyncio.sleep(0.1)  # Simulate read delay
        return round(temperature, 2) 

    async def async_read_data(self, data_type: str) -> float:
            """
            Simulate temperature reading of a heated liquid with thermal inertia.
            
            The temperature changes follow a more realistic pattern with:
            - Gradual heating based on time elapsed
            - Small random fluctuations
            - Thermal inertia (temperature changes more slowly at higher temperatures)
            """
            if data_type != 'Temperature':
                raise ValueError(f"Unsupported data type: {data_type}")
                
            now = datetime.now()
            time_delta = (now - self._last_update).total_seconds()
            self._last_update = now
            
            # Calculate temperature change based on current temperature
            # Higher temperatures change more slowly (thermal inertia)
            inertia_factor = 1.0 - (self._current_temp - self._base_temp) / (self._target_temp - self._base_temp)
            inertia_factor = max(0.1, inertia_factor)  # Ensure some minimum change rate
            
            # Calculate temperature change
            temp_change = self._heating_rate * time_delta * inertia_factor
            
            # Add some random fluctuations (smaller at higher temperatures)
            fluctuation = random.uniform(-0.1, 0.1) * inertia_factor
            
            # Update the temperature
            self._current_temp += temp_change + fluctuation
            
            # Ensure temperature stays within realistic bounds
            self._current_temp = min(self._target_temp, max(self._base_temp, self._current_temp))
            
            # Round to 2 decimal places for realistic sensor behavior
            return round(self._current_temp, 2)