# Base styles
CONTAINER_STYLE = "container"
FORM_GROUP = "form-group"
INPUT_STYLE = "input"

# Text styles
TEXT_BASE = "text"
TEXT_SM = "text-small"
ERROR_TEXT = "error"

# Heading styles
HEADING_LG = "heading"
HEADING_XL = "heading-xl"

# Button styles
BUTTON_PRIMARY = "primary"
BUTTON_SUCCESS = "success"
BUTTON_DANGER = "danger"

# Display styles
TEMP_DISPLAY = "temperature-display"
TEMP_ALERT = "temperature-alert" 