import asyncio
from bleak import BleakClient, BleakGATTCharacteristic, BleakScanner
from bleak.backends.device import BLEDevice
from bleak import BleakScanner
from pasco.pasco_ble_device import PASCOBLEDevice
import asyncio

class AsyncPASCODevice(PASCOBLEDevice):
    """Extended PASCO device class with proper async support"""
    
    # List of compatible PASCO device names
    COMPATIBLE_DEVICES = [
        '//code.Node', 'Accel Alt', 'CO2', 'Conductivity', 
        '//control.Node', 'Current', 'Diffraction', 'Drop Counter',
        'Force Accel', 'Light', 'Load Cell', 'Mag Field', 'Motion',
        'O2', 'Optical DO', 'pH', 'Pressure', 'Rotary Motion',
        'Smart Cart', 'Temperature', 'Voltage', 'Weather',
    ]
    
    def __init__(self):
        super().__init__()
        self._loop = asyncio.get_running_loop()  # Use the current event loop

    @classmethod
    async def scan(cls):
        """Scan for PASCO BLE devices asynchronously
        
        Returns:
            list[BLEDevice]: List of discovered compatible PASCO devices
        """
        found_devices = []
        devices = await BleakScanner.discover()
        
        for device in devices:
            if device.name:
                for compatible_device in cls.COMPATIBLE_DEVICES:
                    if compatible_device in device.name and device not in found_devices:
                        found_devices.append(device)
        
        return found_devices

    @classmethod
    async def connect(cls, device: BLEDevice):
        """Connect to a specific PASCO device asynchronously
        
        Args:
            device (BLEDevice): The Bluetooth device to connect to
            
        Returns:
            AsyncPASCODevice: Connected device instance or None if connection fails
        """
        pasco_device = cls()
        pasco_device._client = BleakClient(device.address)
        
        try:
            await pasco_device._async_connect()
            pasco_device._set_device_params(device)
            pasco_device.initialize_device()
            return pasco_device
        except Exception as e:
            print(f"Failed to connect: {e}")
            return None
        
    async def async_read_data(self, measurement):
        """Async version of read_data"""
        if not self.is_connected():
            raise self.DeviceNotConnected()

        if measurement is None or not isinstance(measurement, str):
            raise self.InvalidParameter
            
        try:
            sensor_id = self._measurement_sensor_ids[measurement]
        except:
            raise self.MeasurementNotFound
            
        await self._async_get_sensor_measurements(sensor_id)
        return self._data_results[measurement]
        
    async def _async_get_sensor_measurements(self, sensor_id):
        """Async version of _get_sensor_measurements"""
        await self._async_request_sensor_data(sensor_id)
        self._data_stack[sensor_id] = self._data_packet
        self._decode_data(sensor_id)
        
    async def _async_request_sensor_data(self, sensor_id):
        """Async version of _request_sensor_data"""
        service_id = sensor_id + 1
        
        for sensor in self._device_channels:
            if sensor['id'] == sensor_id:
                packet_size = sensor['total_data_size']
                
        one_shot_cmd = [self.GCMD_READ_ONE_SAMPLE, packet_size]
        await self.write_await_callback(service_id, one_shot_cmd)

async def main():
    print("Scanning for PASCO devices...")
    found_devices = await AsyncPASCODevice.scan()
    
    if not found_devices:
        print("No PASCO devices found!")
        return
    
    print("\nDevices Found:")
    for i, device in enumerate(found_devices):
        print(f'{i}: {device.name}')
    
    # Device selection
    selected_device = found_devices[0]
    if len(found_devices) > 1:
        while True:
            try:
                selection = int(input('Select a device (number): '))
                if 0 <= selection < len(found_devices):
                    selected_device = found_devices[selection]
                    break
                print("Invalid selection. Please try again.")
            except ValueError:
                print("Please enter a valid number.")
    
    print(f"\nConnecting to {selected_device.name}...")
    pasco_device = await AsyncPASCODevice.connect(selected_device)
    
    if pasco_device:
        print("Successfully connected!")
        measurements = pasco_device.get_measurement_list()
        print("\nAvailable measurements:", measurements)
        
        print("\nReading data samples:")
        try:
            for _ in range(5):
                for measurement in measurements:
                    value = await pasco_device.async_read_data(measurement)
                    print(f"{measurement}: {value}")
                await asyncio.sleep(1)
        except Exception as e:
            print(f"Error reading data: {e}")
        finally:
            pasco_device.disconnect()
            print("\nDisconnected from device")
    else:
        print("Failed to connect to device")


if __name__ == "__main__":
    asyncio.run(main())